package net.mcreator.bleachaddon.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.bleachaddon.init.BleachaddonModItems;

public class StartabilityProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == BleachaddonModItems.CUSTOM_SHIKAI.get()) {
			CustomShikaiSkillProcedure.execute(entity);
		}
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == BleachaddonModItems.CUSTOM_BANKAI.get()) {
			CustomBankaiSkillProcedure.execute(entity);
		}
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == BleachaddonModItems.CUSTOM_TRUE_BANKAI.get()) {
			CustomTrueBankaiSkillProcedure.execute(entity);
		}
	}
}
