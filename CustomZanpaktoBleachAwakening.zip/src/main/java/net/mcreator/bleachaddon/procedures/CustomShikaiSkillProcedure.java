package net.mcreator.bleachaddon.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.bleachaddon.network.BleachaddonModVariables;
import net.mcreator.bleachaddon.init.BleachaddonModItems;
import net.mcreator.bleachaddon.BleachaddonMod;

public class CustomShikaiSkillProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == BleachaddonModItems.CUSTOM_SHIKAI.get()) {
			if ((entity.getCapability(BleachaddonModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new BleachaddonModVariables.PlayerVariables())).Czskill == 1) {
				BleachaddonMod.LOGGER.info("put ability here");
			}
		}
	}
}
