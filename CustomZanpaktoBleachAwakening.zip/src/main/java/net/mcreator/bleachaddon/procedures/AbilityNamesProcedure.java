package net.mcreator.bleachaddon.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

import net.mcreator.bleachaddon.network.BleachaddonModVariables;

public class AbilityNamesProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if ((entity.getCapability(BleachaddonModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new BleachaddonModVariables.PlayerVariables())).Czskill == 1) {
			BleachaddonModVariables.MapVariables.get(world).shikaiabilityname = "placeholder";
			BleachaddonModVariables.MapVariables.get(world).syncData(world);
			BleachaddonModVariables.MapVariables.get(world).bankaiabilityname = "placeholder";
			BleachaddonModVariables.MapVariables.get(world).syncData(world);
			BleachaddonModVariables.MapVariables.get(world).truebankaiabilityname = "placeholder";
			BleachaddonModVariables.MapVariables.get(world).syncData(world);
		}
	}
}
