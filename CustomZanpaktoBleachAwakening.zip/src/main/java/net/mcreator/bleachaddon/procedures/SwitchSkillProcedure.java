package net.mcreator.bleachaddon.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.bleachaddon.network.BleachaddonModVariables;

public class SwitchSkillProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		{
			double _setval = (entity.getCapability(BleachaddonModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new BleachaddonModVariables.PlayerVariables())).Czskill + 1;
			entity.getCapability(BleachaddonModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.Czskill = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		if ((entity.getCapability(BleachaddonModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new BleachaddonModVariables.PlayerVariables())).Czskill == 1) {
			{
				double _setval = 1;
				entity.getCapability(BleachaddonModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.Czskill = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
	}
}
