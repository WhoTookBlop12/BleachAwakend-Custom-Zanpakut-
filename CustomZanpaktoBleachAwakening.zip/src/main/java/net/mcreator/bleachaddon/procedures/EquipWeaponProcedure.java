package net.mcreator.bleachaddon.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.bleachaddon.network.BleachaddonModVariables;
import net.mcreator.bleachaddon.init.BleachaddonModItems;

public class EquipWeaponProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity.getCapability(BleachaddonModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new BleachaddonModVariables.PlayerVariables())).customweaponenable == true) {
			if (entity instanceof ServerPlayer _plr0 && _plr0.level() instanceof ServerLevel && _plr0.getAdvancements().getOrStartProgress(_plr0.server.getAdvancements().getAdvancement(new ResourceLocation("bleachawaken:unlock_shikai"))).isDone()) {
				if (entity.isShiftKeyDown()) {
					if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == BleachaddonModItems.CUSTOM_ZANPACKTO.get()) {
						if (entity instanceof LivingEntity _entity) {
							ItemStack _setstack = new ItemStack(Blocks.AIR).copy();
							_setstack.setCount(1);
							_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
							if (_entity instanceof Player _player)
								_player.getInventory().setChanged();
						}
					}
				} else {
					if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Blocks.AIR.asItem()
							&& !((entity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(BleachaddonModItems.CUSTOM_ZANPACKTO.get())) : false)
									|| (entity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(BleachaddonModItems.CUSTOM_SHIKAI.get())) : false)
									|| (entity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(BleachaddonModItems.CUSTOM_BANKAI.get())) : false)
									|| (entity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(BleachaddonModItems.CUSTOM_TRUE_BANKAI.get())) : false))) {
						if (entity instanceof LivingEntity _entity) {
							ItemStack _setstack = new ItemStack(BleachaddonModItems.CUSTOM_ZANPACKTO.get()).copy();
							_setstack.setCount(1);
							_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
							if (_entity instanceof Player _player)
								_player.getInventory().setChanged();
						}
					}
				}
			}
		}
	}
}
