package net.mcreator.bleachaddon.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.bleachaddon.network.BleachaddonModVariables;
import net.mcreator.bleachaddon.init.BleachaddonModItems;

public class OverlayProcedure {
	public static String execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return "";
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == BleachaddonModItems.CUSTOM_SHIKAI.get()) {
			return BleachaddonModVariables.MapVariables.get(world).shikaiabilityname;
		}
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == BleachaddonModItems.CUSTOM_BANKAI.get()) {
			return BleachaddonModVariables.MapVariables.get(world).bankaiabilityname;
		}
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == BleachaddonModItems.CUSTOM_TRUE_BANKAI.get()) {
			return BleachaddonModVariables.MapVariables.get(world).truebankaiabilityname;
		}
		return "";
	}
}
