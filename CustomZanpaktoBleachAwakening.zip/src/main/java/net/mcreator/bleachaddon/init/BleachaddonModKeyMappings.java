
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bleachaddon.init;

import org.lwjgl.glfw.GLFW;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;

import net.mcreator.bleachaddon.network.UseCustomAbilityMessage;
import net.mcreator.bleachaddon.network.CzTransformMessage;
import net.mcreator.bleachaddon.network.CzEquipWeaponMessage;
import net.mcreator.bleachaddon.BleachaddonMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class BleachaddonModKeyMappings {
	public static final KeyMapping CZ_EQUIP_WEAPON = new KeyMapping("key.bleachaddon.cz_equip_weapon", GLFW.GLFW_KEY_Z, "key.categories.misc") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				BleachaddonMod.PACKET_HANDLER.sendToServer(new CzEquipWeaponMessage(0, 0));
				CzEquipWeaponMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};
	public static final KeyMapping CZ_TRANSFORM = new KeyMapping("key.bleachaddon.cz_transform", GLFW.GLFW_KEY_G, "key.categories.misc") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				BleachaddonMod.PACKET_HANDLER.sendToServer(new CzTransformMessage(0, 0));
				CzTransformMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};
	public static final KeyMapping USE_CUSTOM_ABILITY = new KeyMapping("key.bleachaddon.use_custom_ability", GLFW.GLFW_KEY_B, "key.categories.misc") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				BleachaddonMod.PACKET_HANDLER.sendToServer(new UseCustomAbilityMessage(0, 0));
				UseCustomAbilityMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};
	public static final KeyMapping SWITCH_CUSTOM_SKILL = new KeyMapping("key.bleachaddon.switch_custom_skill", GLFW.GLFW_KEY_R, "key.categories.misc");

	@SubscribeEvent
	public static void registerKeyMappings(RegisterKeyMappingsEvent event) {
		event.register(CZ_EQUIP_WEAPON);
		event.register(CZ_TRANSFORM);
		event.register(USE_CUSTOM_ABILITY);
		event.register(SWITCH_CUSTOM_SKILL);
	}

	@Mod.EventBusSubscriber({Dist.CLIENT})
	public static class KeyEventListener {
		@SubscribeEvent
		public static void onClientTick(TickEvent.ClientTickEvent event) {
			if (Minecraft.getInstance().screen == null) {
				CZ_EQUIP_WEAPON.consumeClick();
				CZ_TRANSFORM.consumeClick();
				USE_CUSTOM_ABILITY.consumeClick();
			}
		}
	}
}
