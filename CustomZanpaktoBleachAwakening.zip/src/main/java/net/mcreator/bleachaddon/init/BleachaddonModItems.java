
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bleachaddon.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.mcreator.bleachaddon.item.CustomZanpacktoItem;
import net.mcreator.bleachaddon.item.CustomTrueBankiaItem;
import net.mcreator.bleachaddon.item.CustomShikaiItem;
import net.mcreator.bleachaddon.item.CustomBankiaItem;
import net.mcreator.bleachaddon.BleachaddonMod;

public class BleachaddonModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, BleachaddonMod.MODID);
	public static final RegistryObject<Item> CUSTOM_ZANPACKTO = REGISTRY.register("custom_zanpackto", () -> new CustomZanpacktoItem());
	public static final RegistryObject<Item> CUSTOM_SHIKAI = REGISTRY.register("custom_shikai", () -> new CustomShikaiItem());
	public static final RegistryObject<Item> CUSTOM_BANKAI = REGISTRY.register("custom_bankai", () -> new CustomBankiaItem());
	public static final RegistryObject<Item> CUSTOM_TRUE_BANKAI = REGISTRY.register("custom_true_bankai", () -> new CustomTrueBankiaItem());
	// Start of user code block custom items
	// End of user code block custom items
}
